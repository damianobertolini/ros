<p align="center">
  <a href="">
    <img src="https://github.com/Gio200023/Fundamentals_of_Robotics/blob/main/logo1.png">
  </a>
  <h2 align="center"> Fundamentals_of_Robotics</h2>

  <p align="center">
  Exam project for Fundamentals of Robotics
  <br>University of Trento 
  </p>
</p>
<br>

# Fundamentals_of_Robotics

Repository for Fundamental_Of_Robotics course at the university of Trento.

Team members: <br>
Giovanni Lunardi <br>
Edoardo Cisco <br>
Federico Carbone <br>
Mattia dalla Costa <br>
